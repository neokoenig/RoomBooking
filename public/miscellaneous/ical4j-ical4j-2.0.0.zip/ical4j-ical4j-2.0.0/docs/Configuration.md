
Configuration Options
=====================

Option: `net.fortuna.ical4j.parser=net.fortuna.ical4j.data.HCalendarParserFactory`

---
Option: `net.fortuna.ical4j.timezone.registry=net.fortuna.ical4j.model.DefaultTimeZoneRegistryFactory`

---
Option: `net.fortuna.ical4j.timezone.update.enabled={true|false}`

---
Option: `net.fortuna.ical4j.factory.decoder=net.fortuna.ical4j.util.DefaultDecoderFactory`

---
Option: `net.fortuna.ical4j.factory.encoder=net.fortuna.ical4j.util.DefaultEncoderFactory`

---
Option: `net.fortuna.ical4j.recur.maxincrementcount=1000`
